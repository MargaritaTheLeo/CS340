# SNHU - CS340
# 6-1 Milestone One: Dashboard Data Visualizations
# Student: Margarita Kiseleva
# Date: 06/13/2024

from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps


class CRUD(object):
    
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS): # adding two parameters to the CRUD class
        
        # Initializing the MongoClient. This helps to access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the animals collection, and the aac user.
        # Definitions of the connection string variables are unique to the individual Apporto environment.

        # Defining connection variables.
        
        # USER and PASS variables are commented out as those will be defined in the ipynb file.
        
        #USER = 'aacuser'
        #PASS = 'simplepass'
       
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30045
        DB = 'AAC'
        COL = 'animals'
        
        # Initializing connection.
        
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

        print("Connection Successful")

    # Defining a method for creating a new animal for the database.
    
    def create(self, data):
        
        """Method to implement the C in CRUD."""

        if data is not None:
            inserted = self.database.animals.insert_one(data) 
            
            # Checking to make sure the insertion was successful.
            
            if inserted != 0:
                return True
            return False
        
        else:
            raise Exception("Nothing to save because data parameter is empty.")
            
    # Defining a method for reading animal data from the database.
    
    def read(self, dataS): # dataS = data to search
        
        """Method to implement the R in CRUD."""

        if dataS is not None:
            read = self.database.animals.find(dataS, {"_id": False})
            
        else:
            raise Exception("Nothing to read because dataS parameter is empty.")
        return read

    # Defining a method for updating animal data in the database.
    
    def update(self, dataS, dataU): # dataS = data to search & dataU = data to update 
        
        """Method to implement the U in CRUD."""

        if dataS and dataU is not None:
            updated = self.database.animals.update_many(dataS, {"$set": dataU})
        
        else:
            raise Exception("Nothing to update because dataS or dataU parameters are empty.")
        return updated.modified_count
    
    # Defining a method for deleting animal data from the database.
    
    def delete(self, dataD): # dataD = data to delete
        
        """Method to implement the D in CRUD."""

        if dataD is not None:
            deleted = self.database.animals.delete_many(dataD)
        else:
            raise Exception("Nothing to delete because dataD parameter is empty.")
        return deleted.deleted_count